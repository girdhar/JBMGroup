from flask import Flask
from DeepNeuralNetworkUtils import *


app = Flask(__name__)

@app.route('/testdefectimage', methods=['GET'])
def getResultFirst():
    modelParams = load_obj("modelParameters.npy")
    imageName = "defect.jpg"
    result = getPrediction(imageName,modelParams )
    return str(result)

@app.route('/testhealthyimage', methods=['GET'])
def getResultSecond():
    modelParams = load_obj("modelParameters.npy")
    imageName = "healthy.jpg"
    result = getPrediction(imageName,modelParams )
    return str(result)

if __name__ == '__main__':
    parameters = load_obj("modelParameters.npy")
    if not parameters:
        print("Data loading.....")
        X_train, X_test, y_train, y_test  = load_images_prepare_dataset()
        if X_train.shape[0] > 0:
            print("Traing the Neural Network Model..........")
            modelParameters = trainModel(X_train, y_train, layers_dims, learning_rate=0.003, num_iterations=3000, print_cost=True)
            print("Traing Completed..........")
            save_obj(modelParameters)
            print("Train Accuracy............")
            predict(X_train, y_train, modelParameters)
            print("Test Accuracy............")
            predict(X_test, y_test, modelParameters)

    app.run()
